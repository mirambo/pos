<?php
if ($sess_allow_add==0)
{
include ('includes/restricted.php');
}
else
{
 ?>
 
 <?php
if (isset($_POST['add_item']))
{
add_test($item_name,$value_at_hand,$reorder_level,$shop_id,$item_value,$item_sp,$item_desc,$date_dep,$user_id);
}
 ?>
<script language="javascript" src="gen_validatorv31.js" type="text/javascript"></script>
<script type="text/javascript" src="calender/calendar.js"></script>
<script type="text/javascript" src="calender/lang/calendar-en.js"></script>
<script type="text/javascript" src="calender/calendar-setup.js"></script>
<style type="text/css">

@import url(calender/calendar-win2k-1.css);

</style>

<Style>
.error_strings{ font-family:Verdana; font-size:10px; color: #FF0000;}
</Style>


<Style>
.error_strings{ font-family:Verdana; font-size:10px; color: #FF0000;}
table1
{
border-collapse:collapse;
}
.table1 td, tr
{
border:1px solid black;
padding:3px;
}

.table
{
border-collapse:collapse;
}

.table td, tr
{
border:1px solid black;
font-size:12px;
</Style>


<!--<form name="new_supplier" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">	-->		
<form name="new_supplier" action="process_add_item.php" method="post">			
			<table width="100%" border="0">
  <tr >
    <td width="18%">&nbsp;</td>
	<td colspan="3" height="30"><?php

if ($_GET['addconfirm']==1)
echo '<div align="center" style="background: #FFCC33; height:20px; width:400px; border:#ff0000 solid 1px; font-size:11px;" class="br-5"> <p align="center"><font color="#ff0000" >Record Created Successfully!!</font></strong></p></div>';
?>
<?php

if ($_GET['passwordmissmatchconfirm']==1)
echo '<div align="center" style="background: #FFCC33; height:20px; width:600px; border:#FF0000 solid 1px; font-size:11px;" class="br-5"> <p align="center"><font color="#FF0000" >Sorry Password do not match!!</font></strong></p></div>';
?>
<?php
if ($_GET['recordexist']==1)
echo '<div align="center" style="background: #FFCC33; height:20px; width:600px; border:#FF0000 solid 1px; font-size:11px;" class="br-5"> <p align="center"><font color="#FF0000" >Sorry!! the record exist</font></strong></p></div>';

if ($_GET['recordexist2']==1)
echo '<div align="center" style="background: #FFCC33; height:20px; width:600px; border:#FF0000 solid 1px; font-size:11px;" class="br-5"> <p align="center"><font color="#FF0000" >Sorry!! The product code exist</font></strong></p></div>';


?></td>
    </tr>
  <tr height="20">
    <td bgcolor="">&nbsp;</td>
    <td width="19%">Select Item Category<font color="#FF0000">*</font></td>
    <td width="23%"><select name="cat_id"><option>-------------------select-----------------</option>
								  <?php
								  
								  $query1="select * from items_category order by cat_name asc";
								  $results1=mysql_query($query1) or die ("Error: $query1.".mysql_error());
								  
								  if (mysql_num_rows($results1)>0)
								  
								  {
									  while ($rows1=mysql_fetch_object($results1))
									  
									  { ?>
										  
                                    <option value="<?php echo $rows1->cat_id; ?>"><?php echo $rows1->cat_name; ?> </option>
                                    
                                
										  
										<?php  }
									  
									  
									  }
								  
								  
								  
								  
								  
								  ?>
								  </select>	</td>
   
  </tr>
   <tr height="20">
    <td bgcolor="">&nbsp;</td>
    <td width="13%">Enter Item Name / Number<font color="#FF0000">*</font></td>
    <td width="30%"><input type="text" size="41" name="item_name"></td>
	 <td width="40%" rowspan="6" valign="top"><div id='new_supplier_errorloc' class='error_strings'></div></td>
   
  </tr> 
  
     <tr height="20">
    <td bgcolor="">&nbsp;</td>
    <td width="13%">Enter Item Code<font color="#FF0000">*</font></td>
    <td width="30%"><input type="text" size="41" name="item_code"></td>
	 <td width="40%" rowspan="6" valign="top"></td>
   
  </tr> 
  
  <tr height="20">
    <td bgcolor="">&nbsp;</td>
    <td width="19%">Value at Hand<font color="#FF0000"></font></td>
	<?php $curr_date=date('Y-m-d');?>
    <td width="23%"><input type="text" size="11" value="0" name="value_at_hand"> As At <input type="text" name="date_dep" size="20" id="date_dep" 
	value="<?php echo $curr_date; ?>" readonly="readonly" />
	
	</td>
  
  </tr> 
  <tr height="20">
    <td bgcolor="">&nbsp;</td>
    <td width="19%">Reorder Point<font color="#FF0000"></font></td>
    <td width="23%"><input type="text" size="41" name="reorder_level"></td>
   
  </tr> 
  
     <tr height="20">
    <td bgcolor="">&nbsp;</td>
    <td width="19%">Item Cost<font color="#FF0000">*</font></td>
    <td width="23%"><input type="text" size="41" name="item_value"></td>
    
  </tr> 
  
<tr height="20">
    <td bgcolor="">&nbsp;</td>
    <td width="19%">Item Selling Price<font color="#FF0000">*</font></td>
    <td width="23%"><input type="text" size="41" name="item_sp"></td>
    
  </tr> 
  
  
  
  <tr height="20">
    <td bgcolor="">&nbsp;</td>
    <td width="19%">Item Description<font color="#FF0000"></font></td>
    <td width="23%"><textarea name="item_desc" cols="40" rows="3"></textarea></td>
    
  </tr> 
 

  
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input type="submit" name="submit" value="Save">
	<input type="hidden" name="add_item" id="add_item" value="1">&nbsp;&nbsp;<input type="reset" value="Cancel"></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

</form>

<script type="text/javascript">

  
   Calendar.setup(
    {
      inputField  : "date_dep",         // ID of the input field
      ifFormat    : " %Y-%m-%d  ",    // the date format
      button      : "date_dep"       // ID of the button
    }
  );
  
  
  
  
  
  </script>

<SCRIPT language="JavaScript">
 var frmvalidator  = new Validator("new_supplier");
 frmvalidator.EnableOnPageErrorDisplaySingleBox();
 frmvalidator.EnableMsgsTogether();
 /*frmvalidator.addValidation("cat_id","dontselect=0",">>Please select item category");*/
 frmvalidator.addValidation("item_name","req",">>Please enter item name");
 frmvalidator.addValidation("item_value","req",">>Please enter item cost");
 frmvalidator.addValidation("item_sp","req",">>Please enter item selling price");

  </SCRIPT>
  <?php 
}
?>
  