<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

<title>Oran Fragrance</title>

<link rel="stylesheet" href="css.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="menu.css" />
<script type="text/javascript" src="menu.js"></script>
	

 
</head>
<body>
<div id="mainmenu">
<?php require_once('mainmenu.php') ?>

</div>

<div id="wrapper">


<div id="content">

<h1>Contact Us</h1>
<P>Flat 1 - Solar House</p>
<P>37 Station Road</p>
<P>n22 6AF</p>
<P>+447528245559</p>







</ul>


</div>

</div>

</div>

<div id="footer">
<img src="images/footerlogo.png" align="center">

</div>



	
</body>
</html>
