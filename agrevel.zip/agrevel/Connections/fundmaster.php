<link rel="stylesheet" type="text/css" href="style.css" />

<?PHP
include('title.php');
error_reporting(0);
$base_url="http://localhost/agrevel/";
$hostname_conneastan = 'localhost';
//set datbase user
$username_conneastan = 'root';
//set database pass
$password_conneastan = '';
//set database name
$database_conneastan = 'agrevel';
//connect to db
date_default_timezone_set('Africa/Nairobi');
$conneastan = mysql_connect($hostname_conneastan, $username_conneastan, $password_conneastan) 
    or die("connection error");
mysql_select_db($database_conneastan) 
   or die("cannot select database");
   
   
   
   
  
   $querycont="select * from company_contacts order by contacts_id desc limit 1";
$resultscont=mysql_query($querycont) or die ("Error: $querycont.".mysql_error());
$rowscont=mysql_fetch_object($resultscont);
?>
