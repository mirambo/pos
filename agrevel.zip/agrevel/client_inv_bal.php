<?php 
    include('Connections/fundmaster.php');
//basic invoice details
//$invoice_id=90;
//$invoice_ttl=0;

 $job_card_id= $_GET['invoice_id'];
 //$job_card_id=2;

$sqlqt="SELECT * FROM sales where sales_id='$job_card_id'";
$resultsqt= mysql_query($sqlqt) or die ("Error $sqlqt.".mysql_error());
$rowsqt=mysql_fetch_object($resultsqt);
$curr_id=$rowsqt->currency;
$curr_rate=$rowsqt->curr_rate;
$discount_perc=$rowsqt->discount; 
$vat=$rowsqt->vat; 


// Task value
$task_totals=0;
$consumable=0;
$task_totals2=0;
$disc=0;
$sqlts="SELECT * from sales_item where sales_id='$job_card_id'";
$resultsts= mysql_query($sqlts) or die ("Error $sqlts.".mysql_error());
if (mysql_num_rows($resultsts) > 0)
						  {
						  while ($rowsts=mysql_fetch_object($resultsts))
						  {
						$service_item_id=$rowsts->sales_id;
						  
$sqlx="SELECT * from sales_item where sales_item_id='$service_item_id'";
$resultsx=mysql_query($sqlx);
$rowsx=mysql_fetch_object($resultsx);
//echo "<i>".$rowsx->service_item_name .' - ';

						  
						  $quant=$rowsts->item_quantity;
						  $task_cost=$rowsts->item_cost*$quant;
						 $task_ttl_kshs=$task_cost*$curr_rate;
						  
						  //cho "</i></br>";
						  $task_totals2=$task_totals2+$task_ttl_kshs;
						  }
						  //echo $task_totals;
			
						  }
						  

$disc_value=$discount_perc/100*$task_totals2;

$sub_ttl1=$task_totals2-$disc_value; 

if ($vat==1)
{


$vat_value=0.16*$sub_ttl1;
}

if ($vat==0)
{


$vat_value=0*$sub_ttl1;

}




//$sub_ttl_vat;



$invoice_amount=$sub_ttl1+$vat_value;




//invoice payments
$grnd_amnt=0;
$sqlpm="select * from invoice_payments where sales_id='$job_card_id'";
$resultspm= mysql_query($sqlpm) or die ("Error $sqlpm.".mysql_error());

while ($rowspm=mysql_fetch_object($resultspm))
						  {
						$amount=$rowspm->amount_received;
						$curr_rate=$rowspm->curr_rate;		  
						
						//$ttl_amount=$rowsts->item_cost*$quant;
						$ttl_amount=$amount*$curr_rate;
						  
						  //cho "</i></br>";
						  $grnd_amnt=$grnd_amnt+$ttl_amount;
						  }
						  //echo $task_totals;
			
						  //}






$task_totals=$invoice_amount-$grnd_amnt;







echo "<span style='float:right; font-weight:bold; color:#ff0000;'>"; 
 
echo number_format($task_totals,2); 

echo "</span></br>";


$job_card_ttl=$job_card_ttl+$task_totals;				  
//othre invoice values
//subtotal 1
//$consumable=$task_totals*0.15;

?>