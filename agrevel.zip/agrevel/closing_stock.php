<?php include('Connections/fundmaster.php'); 

$get_item_id=$_GET['item_id'];
?>

<html xmlns="http://www.w3.org/1999/xhtml">

<script language="javascript" src="gen_validatorv31.js" type="text/javascript"></script>

<Style>
.error_strings{ font-family:Verdana; font-size:10px; color: #FF0000;}
</Style>

<script type="text/javascript"> 

function confirmDelete()
{
    return confirm("Are you sure you want to delete?");
}
</script>
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
<script src="lib/jquery.js" type="text/javascript"></script>
<script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
	jQuery(document).ready(function($) {
	  $('a[rel*=facebox]').facebox({
		loadingImage : 'src/loading.gif',
		closeImage   : 'src/closelabel.png'
	  })
	})
  </script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>

<body>

	<div id="page-wrap">

		<?php include ('header.php')?>
		
		<div id="zone-bar" class="br-5">
          <?php include ('topmenu.php') ?>
		</div>
		
		
		
		<?php require_once('includes/warehousesubmenu.php');  ?>
		
		<h3>::Inventory / Stock</h3>
         
				
		<div id="main-content">
			<div id="feature-content">
			
			<div id="contholder">
			
			<div id="cont-left-full" class="br-5">
			
				
<form name="filter" method="post" action="">				
			
<table width="100%" border="0">
  <tr bgcolor="#FFFFCC">
   
    <td colspan="13" height="30" align="center"> 
	<?php
	
$invoice_no=$_GET['invoice_no'];

if ($_GET['invoice_payment_confirm']==1)
echo '<div align="center" style="background: #FFCC33; height:20px; width:550px; border:#FF0000 solid 1px; font-size:11px;" class="br-5"> <p align="center"><font color="#FF0000" >Payment Received successfully for the Invoice number' ;?> <?php echo $invoice_no;?> <?php echo '</font></strong></p></div>';
?> 

<?php 

if ($_GET['deletemachcatconfirm']==1)
echo "<p align='center'><strong><font color='#FF0000'>Record Deleted!!</font></strong></p>";
?>
	
	</td>
	
    </tr>
	
	
	<tr align="center" height="20">
	<td colspan="13" bgcolor="#FFFFCC" height="20" align="center" >
<strong>Search Item - By Item  
  Category  </strong>
	<select name="location_id"><option value="0">Select..........................................................</option>
								  <?php
								  
								  $query1="select * from items_category order by cat_name asc";
								  $results1=mysql_query($query1) or die ("Error: $query1.".mysql_error());
								  
								  if (mysql_num_rows($results1)>0)
								  
								  {
									  while ($rows1=mysql_fetch_object($results1))
									  
									  { ?>
										  
                                    <option value="<?php echo $rows1->cat_id;?>"><?php echo $rows1->cat_name; ?> </option>
                                    
                                
										  
										<?php  }
									  
									  
									  }
									  
									  
								  
								  
								  
								  
								  
								  ?></select>


	
								  <strong>Or By Code : </strong><input type="text" name="code" size="20">  
								  &nbsp;&nbsp;&nbsp;
								  
								  
								  
								
								  
								  
								  <strong>Or Item Name : </strong><input type="text" name="prod_name" size="40">  
								  &nbsp;&nbsp;&nbsp;
								  
								  
								  
								  <input type="submit" name="generate" value="Filter">
								  
								  
								  
								  
								  
								  </td>
	
    </tr>
	
	<!--<tr bgcolor="#FFFFCC">
	
   
    <td colspan="13" height="20" align="right"><font size="+1">
	
	<?php 
	if (isset($_POST['generate']))
	{
$prod_name=$_POST['prod_name'];
	}
	?>
	
	<a href="print_inventory.php?product_name=<?php echo $prod_name;  ?>" title="Export To Word"><img src="images/word.png" style="margin-right:30px;"/> </a>
	
	
	
	</td>
	</tr>-->
	
  
    <tr style="background:url(images/description.gif);" height="30" >
	<td width="7%"><div align="center"><strong>Item Code</strong></td>
    <td width="18%"><div align="center"><strong>Item Name</strong></td>
    <td width="13%"><div align="center"><strong>Category</strong></td>


    <td width="6%"><div align="center"><strong>Qty Recv</strong></td>
		<!--<td width="5%"><div align="center"><strong>Qty Released</strong></td>-->
	<td width="6%"><div align="center"><strong>Qty Sold</strong></td>

	<td width="6%"><div align="center"><strong>Qty Avlb</strong></td>
	<td width="6%"><div align="center"><strong>BP</strong></td>
	<td width="6%"><div align="center"><strong>Value(Kshs)</strong></td>
	<!--<td width="9%"><div align="center"><strong>Adjust Stock</strong></td>-->
	
    <td width="7%"><div align="center"><strong>Reorder level  </strong></td>
    <td width="8%"><div align="center"><strong>Alert Now</strong></td>
    </tr>
  
  
  <?php  

//$grnd_ttl_cost_of_sales=0;  
if (!isset($_POST['generate']) && isset($_GET['item_id']))
{

$queryop="SELECT * FROM items,items_category,received_stock where received_stock.product_id=items.item_id and 
items.cat_id=items_category.cat_id and received_stock.quantity_rec!='0' and received_stock.product_id='$get_item_id' 
group by received_stock.product_id order by item_name asc";
$results= mysql_query($queryop) or die ("Error $queryop.".mysql_error());	
}
elseif (isset($_POST['generate']) && isset($_GET['item_id']))
{
$queryop="SELECT * FROM items,items_category,received_stock where received_stock.product_id=items.item_id and 
items.cat_id=items_category.cat_id and received_stock.quantity_rec!='0' group by received_stock.product_id order by item_name asc";
$results= mysql_query($queryop) or die ("Error $queryop.".mysql_error());
}

else
{
$code=$_POST['code'];
$prod_name=$_POST['prod_name'];	
$location_id=$_POST['location_id'];	

$queryop= "SELECT * FROM items,items_category,received_stock";
    $conditions = array();
	
if($code!='' ) 
 {
	
      $conditions[] = "items.item_code LIKE '%$code%' ";
} 

 if($prod_name!='') 
 {
	
      $conditions[] = "items.item_name LIKE '%$prod_name%' ";
}

 if($location_id!=0) 
 {
	
      $conditions[] = "items.cat_id='$location_id'";
}


 	
if (count($conditions) > 0) 
	
    
 {


$queryop .= " WHERE " . implode(' AND ', $conditions)." and received_stock.product_id=items.item_id and 
items.cat_id=items_category.cat_id group by received_stock.product_id order by item_name asc";
//$queryop .= " order by task_name asc";
 
 
 }
 
 else
 {

$queryop="SELECT * FROM items,items_category,received_stock where received_stock.product_id=items.item_id and 
items.cat_id=items_category.cat_id group by received_stock.product_id  order by item_name asc";
$results= mysql_query($queryop) or die ("Error $queryop.".mysql_error());
 
 
 }
	
	

    $results = mysql_query($queryop) or die ("Error $queryop.".mysql_error());
	
	
	
}




if (mysql_num_rows($results) > 0)
						  {
							  $RowCounter=0;
							  while ($rows=mysql_fetch_object($results))
							  { 
							  
							  $RowCounter++;
							  if($RowCounter % 2==0)
{
echo '<tr bgcolor="#C0D7E5" height="25">';
}
else 
{
echo '<tr bgcolor="#FFFFCC" height="25" >';
}
 
$prod_id=$rows->item_id;
 ?>
  <td><?php echo $rows->item_code;?></td>
   <td><?php echo $rows->item_name; $curr_sp=$rows->curr_sp; $curr_rate=$rows->exchange_rate;?></td>

<td><?php echo $rows->cat_name;?></td>
    <td align="center">
	
	<?php 
	
$sqlrec="select SUM(quantity_rec) as ttl_rec from received_stock
	where product_id='$prod_id' AND status='1'";
	$resultsrec= mysql_query($sqlrec) or die ("Error $sqlrec.".mysql_error());
	$rowsrec=mysql_fetch_object($resultsrec);
	
 	
	echo number_format($rec_prod=$rowsrec->ttl_rec,0);
	$curr_bp=$rows->curr_bp;
	$curr_sp=$rows->curr_sp;
	
	$ttl_rec=$ttl_rec+$rec_prod;
	
   
	$purchase_order_id=$rows->purchase_order_id; 
	
	
	
	?></td>
		

	<td align="center">
	
	
	<?php 
	
	$sqlsold2="select SUM(item_quantity) as ttl_sold from sales_item
	where item_id='$prod_id'";
	$resultssold2= mysql_query($sqlsold2) or die ("Error $sqlsold2.".mysql_error());
	$rowsold2=mysql_fetch_object($resultssold2);
	
  number_format($prod_sold=$rowsold2->ttl_sold,0);
 
	echo number_format($prod_sold,0);

$ttl_cash_sold=$ttl_cash_sold+$prod_sold;
	

	 
	
	
	?></td>
	

	<td align="center"><strong><font size=""><?php echo $avail_prod=$rec_prod-$prod_sold;
	
	$ttl_avl=$ttl_avl+$avail_prod;
	
	
	
	//echo $rows->curr_bp;?></strong></td>
	<td align="right"><?php echo number_format($curr_bp=$rows->curr_bp,2); ?></td>
	<td align="right"><strong><?php echo number_format($stock_value=$curr_bp*$avail_prod,2); 
	
	$ttl_stock_value=$ttl_stock_value+$stock_value;
	?><strong></td>


<!--<td align="center">

	<?php
if ($user_group_id==15)
{
?>

<a rel="facebox" href="adjust_stock.php?item_id=<?php echo $rows->item_id;?>&avail_stock=<?php echo $avail_prod; ?>">Adjust Stock Item</a>
<?php 

}
else
{
	
	
}
?>

</td>-->
	
	<td align="center"><strong><?php
	
echo $reorder_level=$rows->reorder_level;
	
	
	?></strong></td>
  
	<td align="center">
	
	<?php 
	
	
	if ($reorder_level>=$avail_prod)
	
	{
	
	echo "<blink><font color='#ff0000'>Reorder</font></blink>";
	
	}
	
	
	?>
	
	
	</td>
	
  
    </tr>
  <?php 
  /* $grnt_amnt_ttl_cost=$grnt_amnt_ttl_cost+$ttl_cost;
  $ttl_stock=$ttl_stock+$avail_prod;
  $ttl_qnty_sold=$ttl_qnty_sold+$all_sold_prod;
  $grnd_ttl_cost_of_sales=$grnd_ttl_cost_of_sales+$ttl_cost_of_sales; */
  }
  ?>
  <tr bgcolor="#FFFFCC" height="30">
    <td width="400"><div align="center"><strong></strong></td>
    <td width="400"><div align="center"><strong></strong></td>
	<td width="300"><div align="center"><strong>Totals</strong></td>
	<td width="300"><div align="center"><strong><?php echo number_format($ttl_rec,0); ?></strong></td>
    <td width="300"><div align="center"><strong><?php echo number_format($ttl_cash_sold,0); ?></strong></td>
	<td width="400"><div align="center"><strong><?php echo number_format($ttl_avl,0); ?></strong></td>
	<td width="400"><div align="center"><strong></strong></td>
	<td width="400" colspan="2" align="left"><strong><font size="+1" color="#ff0000"><?php echo number_format($ttl_stock_value,0); ?></font></strong></td>
	<td width="300"><div align="right"><strong></strong></td>
	<!--<td width="300"><div align="right"><strong></strong></td>-->




    </tr>
  
  
  <?php 
  
  
  }
  
  else
  {
  
  ?>
  
  
  <tr bgcolor="#FFFFCC">
   
    <td colspan="13" height="30" align="center"> 
	<font color="#ff0000">No Results found!!</font>
	
	</td>
	
    </tr>
	
	<?
  
  }
  ?>
</table>
</form>		


			

			
			
			
					
			  </div>
				
				
			
			
			</div>
			
			
				
				
				
				
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="footer">
			
			
			<?php include ('footer.php'); ?>
		</div>
		</div>
		
		
		
	</div>
	
	

	
</body>

</html>