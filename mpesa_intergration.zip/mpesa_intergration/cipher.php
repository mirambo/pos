<?php

include 'Crypt/RSA.php';

$rsa = new Crypt_RSA();
extract($rsa->createKey());

$plaintext = 'terrafrost';

$rsa->loadKey($privatekey);
echo $ciphertext = $rsa->encrypt($plaintext);

$rsa->loadKey($publickey);

echo $rsa->decrypt($ciphertext);
 ?>





