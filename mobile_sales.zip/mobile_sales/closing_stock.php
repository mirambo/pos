<?php include('Connections/fundmaster.php'); 


?>

<html xmlns="http://www.w3.org/1999/xhtml">

<script language="javascript" src="gen_validatorv31.js" type="text/javascript"></script>

<Style>
.error_strings{ font-family:Verdana; font-size:10px; color: #FF0000;}
</Style>

<script type="text/javascript"> 

function confirmDelete()
{
    return confirm("Are you sure you want to delete?");
}
</script>
<?php include('includes/facebox.php'); ?>

<body onload="javascript:window.opener.childClosed();window.close();">

	<div id="page-wrap">

		<?php include ('header.php')?>
		
		<div id="zone-bar" class="br-5">
          <?php include ('topmenu.php') ?>
		</div>
		
		
		
		<?php require_once('includes/warehousesubmenu.php');  ?>
		
		<h3>::Inventory / Stock</h3>
         
				
		<div id="main-content">
			<div id="feature-content">
			
			<div id="contholder">
			
			<div id="cont-left-full" class="br-5">
			
				
<form name="filter" method="post" action="">				
			
<table width="100%" border="0">
  <tr bgcolor="#FFFFCC">
   
    <td colspan="13" height="30" align="center"> 
	<?php
	
$invoice_no=$_GET['invoice_no'];

if ($_GET['invoice_payment_confirm']==1)
echo '<div align="center" style="background: #FFCC33; height:20px; width:550px; border:#FF0000 solid 1px; font-size:11px;" class="br-5"> <p align="center"><font color="#FF0000" >Payment Received successfully for the Invoice number' ;?> <?php echo $invoice_no;?> <?php echo '</font></strong></p></div>';
?> 

<?php 

if ($_GET['deletemachcatconfirm']==1)
echo "<p align='center'><strong><font color='#FF0000'>Record Deleted!!</font></strong></p>";
?>
	
	</td>
	
    </tr>
	
	
	<tr align="center" height="40">
	<td colspan="13" bgcolor="#FFFFCC" height="20" align="center" >			  
								  <strong>Search By Product Code : </strong><input type="text" name="code" size="20">  
								  &nbsp;&nbsp;&nbsp;
								  
								  
								  
								
								  
								  
								  <strong>Search By Product Name : </strong><input type="text" name="prod_name" size="40">  
								  &nbsp;&nbsp;&nbsp;
								  
								  
								  
								  <input type="submit" name="generate" value="Filter">
								  
								  
								  
								  <a target="_blank" style="float:right; margin-right:200px; font-weight:bold; font-size:13px; color:#000000" href="print_list_inventory.php">Print</a>						  
<a  style="float:right; margin-right:100px; font-weight:bold; font-size:13px; color:#000000" href="print_list_inventory_excel.php">Export To Excel</a>						  

								  
								  </td>
	
    </tr>
	
	
	
  
    <tr style="background:url(images/description.gif);" height="30" >
	<td width="7%"><div align="center"><strong>Product Code</strong></td>
    <td width="18%"><div align="center"><strong>Product Name</strong></td>

	<td width="10%"><div align="center"><strong>Adjust</strong></td>

    <td width="6%"><div align="center"><strong>Qty Recv</strong></td>
	<td width="6%"><div align="center"><strong>Qty Sold</strong></td>
	<td width="6%"><div align="center"><strong>Sales Ret</strong></td>
	<td width="6%"><div align="center"><strong>Purch Ret</strong></td>
	<td width="6%"><div align="center"><strong>Qty Avlb</strong></td>
	<td width="9%"><div align="center"><strong>Product Value </strong></td>
	<td width="8%"><div align="center"><strong>Ex. Rate</strong></td>
    <td width="10%" ><div align="center"><strong>Product Value(SSP)</strong></td>
    <td width="7%"><div align="center"><strong>Reorder level  </strong></td>
    <td width="16%"><div align="center"><strong>Alert Now</strong></td>
    </tr>
  
  
  <?php 

//$grnd_ttl_cost_of_sales=0;  
$tt_received_prod=0;
if (!isset($_POST['generate']))
{
		 
$sql="select products.pack_size,products.curr_bp,products.curr_sp,products.product_id,products.product_name,products.prod_code,products.exchange_rate,products.reorder_level,SUM(received_stock.quantity_rec) as ttl_quant,
products.weight,received_stock.delivery_date,received_stock.expiry_date,received_stock.order_code_id from product_categories,products,received_stock 
where products.cat_id=product_categories.cat_id AND products.product_id=received_stock.product_id group by received_stock.product_id ORDER BY products.product_name asc";
$results= mysql_query($sql) or die ("Error $sql.".mysql_error());
}
else
{

$code=$_POST['code'];
$prod_name=$_POST['prod_name'];
if ($prod_name!=''&& $code=='')
{
$sql="select products.pack_size,products.curr_bp,products.curr_sp,products.product_id,products.product_name,products.prod_code,products.exchange_rate,products.reorder_level,SUM(received_stock.quantity_rec) as ttl_quant,
products.weight,received_stock.delivery_date,received_stock.expiry_date,received_stock.order_code_id from product_categories,products,received_stock 
where products.cat_id=product_categories.cat_id AND products.product_id=received_stock.product_id AND products.product_name LIKE '%$prod_name%' group by received_stock.product_id ORDER BY products.product_name asc";
$results= mysql_query($sql) or die ("Error $sql.".mysql_error());

}

elseif ($prod_name==''&& $code!='')
{
$sql="select products.pack_size,products.curr_bp,products.curr_sp,products.product_id,products.product_name,products.prod_code,products.exchange_rate,products.reorder_level,SUM(received_stock.quantity_rec) as ttl_quant,
products.weight,received_stock.delivery_date,received_stock.expiry_date,received_stock.order_code_id from product_categories,products,received_stock 
where products.cat_id=product_categories.cat_id AND products.product_id=received_stock.product_id AND products.prod_code LIKE '%$code%' group by received_stock.product_id ORDER BY products.product_name asc";
$results= mysql_query($sql) or die ("Error $sql.".mysql_error());

}

else
{
$sql="select products.pack_size,products.curr_bp,products.curr_sp,products.product_id,products.product_name,products.prod_code,products.exchange_rate,products.reorder_level,SUM(received_stock.quantity_rec) as ttl_quant,
products.weight,received_stock.delivery_date,received_stock.expiry_date,received_stock.order_code_id from product_categories,products,received_stock 
where products.cat_id=product_categories.cat_id AND products.product_id=received_stock.product_id group by received_stock.product_id ORDER BY products.product_name asc";
$results= mysql_query($sql) or die ("Error $sql.".mysql_error());

}





}


if (mysql_num_rows($results) > 0)
						  {
							  $RowCounter=0;
							  while ($rows=mysql_fetch_object($results))
							  { 
							  
							  $RowCounter++;
							  if($RowCounter % 2==0)
{
echo '<tr bgcolor="#C0D7E5" height="25">';
}
else 
{
echo '<tr bgcolor="#FFFFCC" height="25" >';
}
 
 $prod_id=$rows->product_id;	
 ?>
  <td><?php echo $rows->prod_code;?></td>
  <td><?php echo $rows->product_name; $curr_sp=$rows->curr_sp; $curr_rate=$rows->exchange_rate;?></td>
  <td align="center">
 <!-- <a rel="facebox" href="adjust_product.php?product_id=<?php echo $rows->product_id; ?>">Adjust</a>-->
  <a href="adjust_product.php?product_id=<?php echo $rows->product_id; ?>" onclick="javascript:void window.open('adjust_product.php?product_id=<?php echo $rows->product_id; ?>','1368794944167',
'width=700,height=500,toolbar=0,menubar=0,location=0,status=0,scrollbars=0,resizable=1,left=200,top=0');return false;">Adjust</a>
  
  
  
  </td>
    


    <td align="center">
	
	<?php 
	
	 $sqladj="select SUM(quantity_adjusted) as ttl_adj_prod from adjusted_items
	where item_id='$prod_id'";
	$resultsadj= mysql_query($sqladj) or die ("Error $sqladj.".mysql_error());
	$rowsadj=mysql_fetch_object($resultsadj);
	
	 $adj_quant=$rowsadj->ttl_adj_prod;
	
	echo number_format($rec_prod=$rows->ttl_quant+$adj_quant,0);
	
	
	$curr_bp=$rows->curr_bp;
	$curr_sp=$rows->curr_sp;
	
    $prod_id=$rows->product_id;
	$purchase_order_id=$rows->purchase_order_id;
	
	$tt_received_prod=$tt_received_prod+$rec_prod;
	
	?></td>
		
		
		<?php 
//released items	

 $sqlsoldr="select SUM(released_item.released_quantity) as ttl_rel_prod from released_item
	where released_item.item_id='$prod_id' AND status='0'";
	$resultssoldr= mysql_query($sqlsoldr) or die ("Error $sqlsoldr.".mysql_error());
	$rowsoldr=mysql_fetch_object($resultssoldr);
	
 //echo number_format($releases_prod=$rowsoldr->ttl_rel_prod,0);

 //sold items 
$sqlsold="select SUM(requisition_item.item_quantity) as ttl_sold_prod from requisition_item
	where requisition_item.item_id='$prod_id'";
	$resultssold= mysql_query($sqlsold) or die ("Error $sqlsold.".mysql_error());
	$rowsold=mysql_fetch_object($resultssold);
	
  
 






		?>

	<td align="center">
	
	
	<?php 
	 echo number_format($sold_prod=$rowsold->ttl_sold_prod,0);
	
	
	?></td>
	<td align="center"><?php 
	

$sq="select SUM(sales_returns_items.quantity) as ttl_sales_ret from sales_returns_items where sales_returns_items.product_id='$prod_id'";
$res= mysql_query($sq) or die ("Error $sq.".mysql_error());
$ro=mysql_fetch_object($res);

$sales_ret=$ro->ttl_sales_ret;	
echo number_format($sales_ret,0);

$ttl_sr=$ttl_sr+$sales_ret;	
	
	
	
	//echo number_format($prod_ret,0);
	
	
	
	
	?></td>
	<td align="center"><?php 
$prod_id=$rows->product_id;	
$sqlstockret="select SUM(purchase_returns_items.quantity) as ttl_stock_ret from purchase_returns_items where purchase_returns_items.product_id='$prod_id'";
$resultsstockret= mysql_query($sqlstockret) or die ("Error $sqlstockret.".mysql_error());
$rowsstockret=mysql_fetch_object($resultsstockret);

$stock_ret=$rowsstockret->ttl_stock_ret;	
echo number_format($stock_ret,0);

$ttl_pr=$ttl_pr+$stock_ret;
	
	
	
	
	?></td>
	<td align="center"><?php echo $avail_prod=$rec_prod-$sold_prod+$sales_ret-$stock_ret;//echo $rows->curr_bp;?></td>
	<td align="right"><?php echo number_format($bp=$rows->curr_bp,2);?></td>
	<td align="right"><?php echo number_format($curr_rate=$rows->exchange_rate,2);?></td>

	<td align="right"><?php 
	
	
	echo number_format($ttl_cost=$avail_prod*$bp*$curr_rate,2);
	
	
	
	
	?>
	
	
	
	
	
	</td>
	
	<td align="center"><strong><?php
	
echo $reorder_level=$rows->reorder_level;
	
	
	?></strong></td>
  
	<td align="center">
	
	<?php 
	
	
	if ($reorder_level>=$avail_prod)
	
	{
	
	echo "<blink><font color='#ff0000'>Reorder</font></blink>";
	
	}
	
	
	?>
	
	
	</td>
	
  
    </tr>
  <?php 
  $grnt_amnt_ttl_cost=$grnt_amnt_ttl_cost+$ttl_cost;
  $ttl_stock=$ttl_stock+$avail_prod;
  $ttl_qnty_sold=$ttl_qnty_sold+$sold_prod;
  $grnd_ttl_cost_of_sales=$grnd_ttl_cost_of_sales+$ttl_cost_of_sales;
  }
  ?>
  <tr bgcolor="#FFFFCC" height="30">
    <td width="400"><div align="center"><strong></strong></td>
    <td width="400"><div align="center"><strong></strong></td>
	<td width="300"><div align="center"><strong></strong></td>
	<td width="300"><div align="center"><strong><?php echo number_format($tt_received_prod,0);?></strong></td>
	
    <td width="300"><div align="center"><strong><?php echo $ttl_qnty_sold; ?></strong></td>
		<td width="400"><div align="center"><strong><?php echo $ttl_sr; ?></strong></td>
	<td width="300"><div align="center"><strong><?php echo $ttl_pr; ?></strong></td>

	<td width="400"><div align="center"><strong><?php echo $ttl_stock; ?></strong></td>
	<td width="300"><div align="center"></td>
	<td width="300"><div align="right"><strong></strong></td>

	<td width="300"><div align="right"><strong><?php echo number_format($grnt_amnt_ttl_cost,2);?></strong></td>

	<td width="300"><div align="center"></td>
	<td width="300"><div align="center"></td>

	<!--<td width="200"><div align="center"><strong><font size="+1"><?php echo number_format($grnt_amnt,2); ?></font></strong></td>
	<td width="200"><div align="center"><strong></strong></td>
    <td width="100" ><div align="center"><strong>Edit</strong></td>
    <td width="100"><div align="center"><strong>Delete</strong></td>-->
    </tr>
  
  
  <?php 
  
  
  }
  
  else
  {
  
  ?>
  
  
  <tr bgcolor="#FFFFCC">
   
    <td colspan="13" height="30" align="center"> 
	<font color="#ff0000">No Results found!!</font>
	
	</td>
	
    </tr>
	
	<?
  
  }
  ?>
</table>
</form>		


			

			
			
			
					
			  </div>
				
				
			
			
			</div>
			
			
				
				
				
				
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</div>
			<div id="footer">
			
			
			<?php include ('footer.php'); ?>
		</div>
		</div>
		
		
		
	</div>
	
	

	
</body>

</html>